#pragma once
#include <glm.hpp>
#include "..\..\Graphics\window.h"
#include "..\..\Camera\camera.h"

class Ship
{
    private:
        glm::vec3 position;
        float speed;

    public:
        Ship();
        Ship(glm::vec3 position, float speed);
        ~Ship();

        //void moveShip(Window window);

        glm::vec3 getPosition();
        float getSpeed();
    
        void setPosition(glm::vec3 position);

};

