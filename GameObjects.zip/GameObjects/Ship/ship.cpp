#include "ship.h"

Ship::Ship()
{
    this->position = glm::vec3(0.0f, -0.0f, 0.0f);
}

Ship::Ship(glm::vec3 position, float speed)
{
    this->position = position;
    this->speed = speed;

}

Ship::~Ship()
{
}

//void Ship::moveShip(Window window)
//{
//    if (window.isPressed(GLFW_KEY_W))
//        this->position = this->position + glm::vec3(0, 0, -this->speed);
//    if (window.isPressed(GLFW_KEY_S))
//        this->position = this->position + glm::vec3(0, 0, this->speed);
//    if (window.isPressed(GLFW_KEY_A))
//        this->position = this->position + glm::vec3(-this->speed, 0, 0);
//    if (window.isPressed(GLFW_KEY_D))
//        this->position = this->position + glm::vec3(this->speed, 0, 0);
//}

glm::vec3 Ship::getPosition()
{
    return this->position;
}

float Ship::getSpeed()
{
    return this->speed;
}

void Ship::setPosition(glm::vec3 position)
{
    this->position = position;
}